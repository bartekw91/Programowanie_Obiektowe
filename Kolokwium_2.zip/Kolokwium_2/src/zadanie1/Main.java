package zadanie1;

public class Main {
    public static void main(String[] args)
    {
        Building budynek = new Building(123.0, "Czarny");
        House domek = new House(500, "Czerwony", 5);
        System.out.println(budynek);
        System.out.println(domek);
    }
}
