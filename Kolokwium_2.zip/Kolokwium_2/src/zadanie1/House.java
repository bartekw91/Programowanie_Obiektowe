package zadanie1;

public class House extends Building{
    private int numberOfRooms;
    public House(double wysokosc, String kolor, int lPokoji)
    {
        super(wysokosc, kolor);
        if(lPokoji >= 3)
            this.numberOfRooms = lPokoji;
        else
            throw new IllegalArgumentException("Liczba pokoji ma być większa niż 2!");
    }
    @Override
    public String toString()
    {
        return "Wysokość: " + super.height + " m, Kolor: " + super.color + ", L. Pokoji: "
                + this.numberOfRooms;
    }
}
