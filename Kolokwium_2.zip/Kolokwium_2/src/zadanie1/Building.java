package zadanie1;

public class Building {
    protected double height;
    protected String color;

    public Building(double wysokosc, String kolor)
    {
        if(wysokosc > 0)
            this.height = wysokosc;
        else
            throw new IllegalArgumentException("Wysokośc nie może być ujemna!");
        if(!kolor.isBlank())
            this.color = kolor;
        else
            throw new IllegalArgumentException("Pole nie może byc puste!");
    }

    @Override
    public String toString()
    {
        return "Wysokość: " + this.height + " m, Kolor: " + this.color;
    }
}
