package zadanie6;

public class Tester implements Comparable<Tester>{
    private String wyraz;
    private int liczba;

    public Tester(String wyraz, int liczba)
    {
        this.wyraz = wyraz;
        this.liczba = liczba;
    }

    @Override
    public int compareTo(Tester t)
    {
        return this.liczba - t.liczba;
    }
    @Override
    public String toString()
    {
        return "Wyraz: " + this.wyraz + ", Liczba: " + this.liczba;
    }
}
