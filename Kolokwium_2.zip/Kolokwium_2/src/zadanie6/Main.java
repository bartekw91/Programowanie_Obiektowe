package zadanie6;

import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args)
    {
        Integer[] liczby = {5,3,1,8,9};
        System.out.println(Arrays.toString(liczby));
        Main.sortDescending(liczby);
        System.out.println(Arrays.toString(liczby));

        System.out.println();

        Double[] liczbyD = {7.77, 3.14, 1.00, 2.32};
        System.out.println(Arrays.toString(liczbyD));
        Main.sortDescending(liczbyD);
        System.out.println(Arrays.toString(liczbyD));

        String[] wyrazy = {"kota", "ala", "ma"};
        System.out.println(Arrays.toString(wyrazy));
        Main.sortDescending(wyrazy);
        System.out.println(Arrays.toString(wyrazy));
        //SPRAWDZENIE SORTOWANIE Z WŁASNYM OBIEKTEM
        System.out.println();
        Tester[] test = {new Tester("Dada", 1),
                         new Tester("Negative", -50),
        new Tester("Donkey", 12),
        new Tester("Papi", 23)};
        for(Tester a : test)
        {
            System.out.println(a);
        }

        System.out.println();

        Main.sortDescending(test);
        for(Tester a : test)
        {
            System.out.println(a);
        }
    }
    public static <T extends Comparable<T>> void sortDescending(T[] tablica)
    {
        Arrays.sort(tablica,Comparator.reverseOrder());
    }
}
