package zadanie2;

public class Main {
    public static void main(String[] args)
    {
        Bitmap bitmapa = new Bitmap(1024, 768, "rock.bmp");
        Vector wektor = new Vector(1920, 1080, "balwan.svg");

        bitmapa.loadFile();
        bitmapa.saveFile();
        wektor.loadFile();
        wektor.saveFile();
    }
}
