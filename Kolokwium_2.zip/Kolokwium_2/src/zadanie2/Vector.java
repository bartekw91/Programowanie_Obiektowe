package zadanie2;

public class Vector extends ComputerGraphic{
    public Vector(int szerokosc, int dlugosc, String nazwa)
    {
        this.width = szerokosc;
        this.height = dlugosc;
        this.fileName = nazwa;
    }
    @Override
    public void loadFile() {
        System.out.println("Wczytuję plik wektorowy...");
    }
    @Override
    public void saveFile()
    {
        System.out.println("Zapisuję plik wektorowy...");
    }
}
