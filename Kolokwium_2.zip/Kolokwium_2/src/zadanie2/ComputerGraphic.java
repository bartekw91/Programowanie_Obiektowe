package zadanie2;

public abstract class ComputerGraphic {
    protected int width;
    protected int height;
    protected String fileName;
    public abstract void loadFile();
    public abstract void saveFile();
}
