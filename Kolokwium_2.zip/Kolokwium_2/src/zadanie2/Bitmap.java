package zadanie2;

public class Bitmap extends ComputerGraphic{
    public Bitmap(int szerokosc, int dlugosc, String nazwa)
    {
        this.width = szerokosc;
        this.height = dlugosc;
        this.fileName = nazwa;
    }
    @Override
    public void loadFile() {
        System.out.println("Wczytuję plik bitmapowy...");
    }
    @Override
    public void saveFile()
    {
        System.out.println("Zapisuję plik bitmapowy...");
    }
}
