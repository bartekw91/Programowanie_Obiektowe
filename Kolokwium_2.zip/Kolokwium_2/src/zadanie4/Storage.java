package zadanie4;

public class Storage<T>{
    private T object;
    public void store(T item)
    {
        System.out.println("Przechowuję obiekt");
        this.object = item;
    }
    public T retrieve()
    {
        System.out.println("Wyjmuje obiekt...");
        T temp = this.object;
        this.object = null;
        return temp;
    }

    @Override
    public String toString()
    {
        if(this.object == null)
            return "Magazyn jest pusty";
        else
            return "Magazyn zawiera: " + this.object + ", Typ: "+ this.object.getClass();
    }
}
