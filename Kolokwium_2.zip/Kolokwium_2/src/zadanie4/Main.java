package zadanie4;

public class Main {
    public static void main(String[] args)
    {
        Storage<String> wyraz = new Storage<String>();
        wyraz.store("Palmolive");
        System.out.println(wyraz);
        wyraz.retrieve();
        System.out.println(wyraz);
        System.out.println();

        Storage<Integer> liczba = new Storage<>();
        liczba.store(777);
        System.out.println(liczba);
        liczba.retrieve();
        System.out.println(liczba);

    }
}
