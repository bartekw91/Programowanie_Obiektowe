package zadanie3;

public class AudioPlayer implements MediaPlayer{
    private String currentTrack;
    @Override
    public void play(String trackName) {
        if(trackName.isBlank() || trackName.isEmpty())
            throw new IllegalArgumentException("No music file has been mentioned");
        else
        {
            this.currentTrack = trackName;
            System.out.println("Playing " + this.currentTrack);
        }
    }

    @Override
    public void pause() {
        System.out.println("Music paused");
    }

    @Override
    public String getCurrentTrack() {
        if(this.currentTrack == null)
        {
            return "No music is currently being played";
        }
        else
        {
            return "Currently playing " + this.currentTrack;
        }
    }
}
