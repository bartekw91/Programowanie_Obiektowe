package zadanie3;

public class VideoPlayer implements MediaPlayer{
    private String videoFile;
    @Override
    public void play(String trackName) {
        if(trackName.isBlank() || trackName.isEmpty())
            throw new IllegalArgumentException("No video file has been mentioned");
        else
        {
            this.videoFile = trackName;
            System.out.println("Playing " + this.videoFile);
        }
    }

    @Override
    public void pause() {
        System.out.println("Music paused");
    }

    @Override
    public String getCurrentTrack() {
        if(this.videoFile == null)
        {
            return "No music is currently being played";
        }
        else
            return "Currently playing " + this.videoFile;
    }
}
