package zadanie3;

public class Main {
    public static void main(String[] args)
    {
        AudioPlayer odtwarzaczMp3 = new AudioPlayer();
        VideoPlayer odtwarzaczDvd = new VideoPlayer();

        System.out.println(odtwarzaczMp3.getCurrentTrack());
        odtwarzaczMp3.play("Rick Astley - Never Gonna Give You Up.mp3");
        System.out.println(odtwarzaczMp3.getCurrentTrack());
        odtwarzaczMp3.pause();
        System.out.println();
        System.out.println(odtwarzaczDvd.getCurrentTrack());
        odtwarzaczDvd.play("Bad Apple.mp4");
        System.out.println(odtwarzaczDvd.getCurrentTrack());
        odtwarzaczDvd.pause();
    }
}
