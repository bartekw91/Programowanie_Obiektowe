package zadanie3;

public interface MediaPlayer {
    public void play(String trackName);
    public void pause();
    public String getCurrentTrack();
}
