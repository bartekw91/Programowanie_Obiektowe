package zadanie5;

public class UserAuthentication implements Authentication{
    private String login;
    private String haslo;
    public UserAuthentication(String login, String haslo)
    {
        if(!login.isBlank())
            this.login = login;
        else
            throw new IllegalArgumentException("Login nie może byc pusty!");
        if(!haslo.isBlank())
            this.haslo = haslo;
        else
            throw new IllegalArgumentException("Hasło nie może być puste!");
    }

    @Override
    public boolean login(String username, String password) {
        if(this.login.equals(username))
        {
            if ((this.haslo.equals(password)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        return false;
    }

    @Override
    public void logout() {
        System.out.println("Wylogowuję użytkownika "+ this.login + "...");
    }

    @Override
    public boolean resetPassword(String username, String oldPassword, String newPassword) {
        if(this.login.equals(username))
        {
            if(this.haslo.equals(oldPassword))
            {
                System.out.println("Zmieniam hasło użytkownika...");
                this.haslo = newPassword;
            }
            else
            {
                return false;
            }
        }
        return false;
    }
    @Override
    public String toString()
    {
        return "Login: " + this.login + ", Hasło: " + this.haslo;
    }
}
