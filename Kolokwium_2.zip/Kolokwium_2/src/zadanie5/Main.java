package zadanie5;

public class Main {
    public static void main(String[] args)
    {
        UserAuthentication uzytkownik = new UserAuthentication("Bati", "12345");
        AdminAuthentication admin = new AdminAuthentication("Papa", "77777");

        boolean correctU = uzytkownik.login("Bati", "12345");
        if(correctU) {
            System.out.println("Zalogowano");
            System.out.println(uzytkownik);
        }
        else
        {
            throw new IllegalArgumentException("Niepoprawny użytkownik lub hasło!");
        }
        boolean correctA = admin.login("Papa", "77777");
        if(correctA) {
            System.out.println("Zalogowano");
            System.out.println(admin);
        }
        else
        {
            throw new IllegalArgumentException("Niepoprawny administrator lub hasło!");
        }
        System.out.println();
        uzytkownik.resetPassword("Bati", "12345", "54321");
        System.out.println(uzytkownik);
        admin.resetPassword("Papa", "77777", "00000");
        System.out.println(admin);
        System.out.println();
        uzytkownik.logout();
        admin.logout();
    }
}
