public class nr2 {
    public static int[] podciag(int[] tab)
    {
        int max_ciag = 0;
        int temp_ciag = 0;
        int save_pos = 0;
        for(int i = 0; i < tab.length-1;i++)
        {
            if(tab[i] < tab[i+1])
            {
                temp_ciag++;
            }
            else
            {
                max_ciag = Math.max(max_ciag, temp_ciag);
                temp_ciag = 0;
            }
        }
        int[] tab_wynik = new int[max_ciag];

//        max_ciag = Math.max(max_ciag, temp_ciag);
        return tab_wynik;
    }
}
