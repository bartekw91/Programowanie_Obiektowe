public class nr1 {
    public static boolean dokladnosc(int x, int y, int k)
    {
        int wynik = Math.abs(x - y);
        return wynik <= Math.pow(10, k*-1);
    }
    public static int najblizszySasiad(int S)
    {
        int wynik = 1;
        for(int i = 1; i*i < S; i++)
        {
            if(Math.abs(S - (i*i)) > Math.abs(S - ((i+1)*(i+1)))) wynik = i+1;
            else wynik = i;
        }
        return wynik;
    }
    public static double pierwiastek(int S, int n, int k)
    {
        int x = najblizszySasiad(S);
        int xn1 = 0;
        while(!dokladnosc(xn1, x, k))
        {
            for(int i = 0; i < n-2;)
            x=xn1;
        }
        return xn1;
    }
}
