public class Main {
    public static void main(String[] args)
    {
//        int[] tablica = {1, 2, 0, 3, 5, 1, 4};
//        nr2.podciag(tablica);
//        System.out.println("Najbliższy sąsiad dla 20 jest:" + nr1.najblizszySasiad(32));
//        nr3.palindromLiczbowy(3);
        }
}