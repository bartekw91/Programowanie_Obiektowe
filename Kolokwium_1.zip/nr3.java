public class nr3 {
    public static boolean czyPalindrom(int n)
    {
        int n_copy = n;
        int wynik = 0;
        int ile_cyfr = -1;
        for(int i = 0;n_copy > 0;ile_cyfr++)
        {
            n_copy /= 10;
        }

        n_copy = n;

        for(int i=ile_cyfr;n_copy > 0;i--)
        {
            int multi = (int)Math.pow(10, i);
            int cyfra = n_copy % 10;
            wynik += cyfra * multi;
            n_copy -= cyfra;
            n_copy /= 10;
        }
        return (wynik == n);
    }
    public static void palindromLiczbowy(int m)
    {
        if (m > 1)
        {
            m = (int)Math.pow(10, (double)m-1%10);
            for(int i = m; i<=m*10; i++)
            {
                for(int j = i;j <= i;j++)
                {
                    int liczba1 = i;
                    int liczba2 = j;
                    int wynik = liczba1 * liczba2;
                    if (czyPalindrom(wynik)) System.out.println(liczba1 + " x " + liczba2 + " = " + wynik);
                }
            }
        }
    }
}
